import struct
import sys
import os

class L3Archiver:
    # Сигнатура формата
    SIGNATURE = b'L3ARCH'
    # Версия формата для задания Л3.№1
    VERSION = 0
    
    @staticmethod
    def encode(input_file, output_file):
        """
        Кодер: создает архив из исходного файла
        """
        try:
            # Читаем исходный файл
            with open(input_file, 'rb') as f:
                original_data = f.read()
            
            # Получаем длину файла
            original_length = len(original_data)
            
            # Создаем архив
            with open(output_file, 'wb') as f:
                # Записываем сигнатуру (6 байт)
                f.write(L3Archiver.SIGNATURE)
                
                # Записываем версию формата (2 байта)
                f.write(struct.pack('<H', L3Archiver.VERSION))
                
                # Записываем длину файла (8 байт)
                f.write(struct.pack('<Q', original_length))
                
                # Записываем сырые данные
                f.write(original_data)
            
            print(f"Файл '{input_file}' успешно заархивирован в '{output_file}'")
            print(f"Исходный размер: {original_length} байт")
            print(f"Размер архива: {16 + original_length} байт")
            
        except Exception as e:
            print(f"Ошибка при кодировании: {e}")
    
    @staticmethod
    def decode(input_file, output_file):
        """
        Декодер: восстанавливает файл из архива
        """
        try:
            with open(input_file, 'rb') as f:
                # Читаем сигнатуру (6 байт)
                signature = f.read(6)
                
                # Проверяем сигнатуру
                if signature != L3Archiver.SIGNATURE:
                    raise ValueError("Неверная сигнатура формата")
                
                # Читаем версию (2 байта)
                version = struct.unpack('<H', f.read(2))[0]
                
                # Проверяем версию
                if version != L3Archiver.VERSION:
                    raise ValueError(f"Неверная версия формата: {version}")
                
                # Читаем длину файла (8 байт)
                original_length = struct.unpack('<Q', f.read(8))[0]
                
                # Читаем исходные данные
                original_data = f.read(original_length)
            
            # Проверяем, что прочитали правильное количество данных
            if len(original_data) != original_length:
                raise ValueError("Неверная длина данных в архиве")
            
            # Сохраняем восстановленный файл
            with open(output_file, 'wb') as f:
                f.write(original_data)
            
            print(f"Архив '{input_file}' успешно распакован в '{output_file}'")
            print(f"Восстановленный размер: {original_length} байт")
            
        except Exception as e:
            print(f"Ошибка при декодировании: {e}")
    
    @staticmethod
    def print_usage():
        print("Использование:")
        print("  Кодирование: python l3archiver.py encode <входной_файл> <выходной_архив>")
        print("  Декодирование: python l3archiver.py decode <входной_архив> <выходной_файл>")
        print("  Помощь: python l3archiver.py help")

def main():
    if len(sys.argv) < 2:
        L3Archiver.print_usage()
        return
    
    command = sys.argv[1].lower()
    
    if command == 'encode':
        if len(sys.argv) != 4:
            print("Ошибка: для кодирования укажите входной и выходной файлы")
            L3Archiver.print_usage()
            return
        L3Archiver.encode(sys.argv[2], sys.argv[3])
    
    elif command == 'decode':
        if len(sys.argv) != 4:
            print("Ошибка: для декодирования укажите входной архив и выходной файл")
            L3Archiver.print_usage()
            return
        L3Archiver.decode(sys.argv[2], sys.argv[3])
    
    elif command == 'help':
        L3Archiver.print_usage()
    
    else:
        print(f"Неизвестная команда: {command}")
        L3Archiver.print_usage()

if __name__ == "__main__":
    main()