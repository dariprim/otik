import struct
import sys
import os
import zlib
import argparse
from pathlib import Path
from binascii import crc_hqx, crc32

# Константы формата
SIGNATURE = b'L3ARCH02'            # 8 байт (первые 6 совпадают с L3ARCH)
SIGNATURE_PREFIX = b'L3ARCH'       # первые 6 байт (требование совместимости)
VERSION = 1                        # uint16

# Algorithm codes
ALG_CTX_NONE = 0
ALG_NOCTX_NONE = 0
ALG_NOCTX_ZLIB = 2
ALG_PROT_NONE = 0
ALG_PROT_CRC32 = 11

RESERVED = 0

# Entry types
ENTRY_DIR = 0
ENTRY_FILE = 1

MAX_PATH_DEPTH = 4  # ограничение уровня вложенности


def _rel_path_components(path: Path):
    """Возвращает компоненты пути как список (без пустых)."""
    return [p for p in path.parts if p and p not in ('.', '/')]


def _check_depth_ok(rel_path: str):
    # считаем уровни по разделителю '/'
    depth = rel_path.count('/')
    return depth <= (MAX_PATH_DEPTH - 1)  # depth=0 => file in root; уровней <=3 => путь длины 4 с файлом


def collect_entries(inputs):
    """
    Собирает записи (файлы и директории) из списка входных путей.
    Возвращает список dict:
      { 'type': ENTRY_FILE|ENTRY_DIR,
        'relpath': 'a/b/c.txt',
        'orig_path': '/abs/...',  # absolute path on filesystem
        'orig_size': int }
    """
    entries = []
    seen_paths = set()

    for inp in inputs:
        p = Path(inp)
        if not p.exists():
            print(f"Предупреждение: '{inp}' не найден — пропускаю", file=sys.stderr)
            continue

        base = p.parent if p.is_file() else p
        # Если передали несколько аргументов, используем их имена как корни; но в архив запишем относительный путь
        if p.is_file():
            rel = p.name
            if not _check_depth_ok(rel):
                print(f"Предупреждение: путь '{p}' глубже {MAX_PATH_DEPTH}, пропускаю", file=sys.stderr)
                continue
            if rel in seen_paths:
                print(f"Предупреждение: файл '{rel}' уже добавлен — пропускаю", file=sys.stderr)
                continue
            entries.append({'type': ENTRY_FILE, 'relpath': rel, 'orig_path': str(p.resolve()), 'orig_size': p.stat().st_size})
            seen_paths.add(rel)
        else:
            # рекурсивно обходим дерево, но сохраняем относительные пути от корня p
            for root, dirs, files in os.walk(p):
                root_path = Path(root)
                rel_root = root_path.relative_to(p)  # '.' for root
                # добавляем директории (включая корень? не нужно добавлять корень как запись)
                for d in dirs:
                    rel = os.path.join(str(rel_root), d) if str(rel_root) != '.' else d
                    rel_unix = rel.replace('\\', '/')
                    if not _check_depth_ok(rel_unix):
                        print(f"Предупреждение: директория '{rel_unix}' глубже {MAX_PATH_DEPTH}, пропускаю содержимое", file=sys.stderr)
                        continue
                    if rel_unix in seen_paths:
                        continue
                    entries.append({'type': ENTRY_DIR, 'relpath': rel_unix, 'orig_path': None, 'orig_size': 0})
                    seen_paths.add(rel_unix)
                # файлы
                for fname in files:
                    rel = os.path.join(str(rel_root), fname) if str(rel_root) != '.' else fname
                    rel_unix = rel.replace('\\', '/')
                    if not _check_depth_ok(rel_unix):
                        print(f"Предупреждение: файл '{rel_unix}' глубже {MAX_PATH_DEPTH}, пропускаю", file=sys.stderr)
                        continue
                    if rel_unix in seen_paths:
                        print(f"Предупреждение: путь '{rel_unix}' уже добавлен — пропускаю", file=sys.stderr)
                        continue
                    fpath = root_path / fname
                    entries.append({'type': ENTRY_FILE, 'relpath': rel_unix, 'orig_path': str(fpath.resolve()), 'orig_size': fpath.stat().st_size})
                    seen_paths.add(rel_unix)

    # sort entries in deterministic order (dirs first, then files), to make format reproducible
    entries.sort(key=lambda e: (e['relpath'].count('/'), e['type'], e['relpath']))
    return entries


def build_archive(entries, out_path, compress=False, crc=False):
    """
    Построить архив по списку entries (см. collect_entries).
    """
    alg_ctx = ALG_CTX_NONE
    alg_noctx = ALG_NOCTX_ZLIB if compress else ALG_NOCTX_NONE
    alg_prot = ALG_PROT_CRC32 if crc else ALG_PROT_NONE

    # сначала подготовим служебные данные и сами закодированные блоки
    data_blocks = []   # list of bytes
    entry_service = [] # list of bytes for service fields (per-entry)
    stored_sizes = []
    orig_sizes = []

    for ent in entries:
        if ent['type'] == ENTRY_DIR:
            stored_sizes.append(0)
            orig_sizes.append(0)
            entry_service.append(b'')
            data_blocks.append(b'')
            continue

        # file: читаем контент
        with open(ent['orig_path'], 'rb') as f:
            raw = f.read()
        orig_size = len(raw)

        # compress if requested (non-context algorithm)
        if compress:
            stored = zlib.compress(raw)
        else:
            stored = raw

        service = b''
        # protection: CRC32 of original data (store 4-byte big-endian)
        if crc:
            c = crc32(raw) & 0xffffffff
            service = struct.pack('<I', c)  # little-endian 4 байта
        stored_sizes.append(len(stored))
        orig_sizes.append(orig_size)
        entry_service.append(service)
        data_blocks.append(stored)

    # Теперь подготовим таблицу записей
    # фиксированная часть длины заголовка: 8 + 2 +1+1+1+1 +8 +4 = 26 байт
    FIXED_HEADER_LEN = 8 + 2 + 1 + 1 + 1 + 1 + 8 + 4

    # пост-фикс: таблица записей — динамическая
    table_bytes = bytearray()
    for i, ent in enumerate(entries):
        entry_type = ent['type']
        relpath_bytes = ent['relpath'].encode('utf-8')
        path_len = len(relpath_bytes)
        service_bytes = entry_service[i]
        service_len = len(service_bytes)
        orig_sz = orig_sizes[i]
        stored_sz = stored_sizes[i]
        # pack: 1 byte type, 2 byte path_len, path, 8 byte orig_size, 8 byte stored_size, 4 byte service_len, service
        table_bytes += struct.pack('<B', entry_type)
        table_bytes += struct.pack('<H', path_len)
        table_bytes += relpath_bytes
        table_bytes += struct.pack('<Q', orig_sz)
        table_bytes += struct.pack('<Q', stored_sz)
        table_bytes += struct.pack('<I', service_len)
        if service_len:
            table_bytes += service_bytes

    header_size = FIXED_HEADER_LEN + len(table_bytes)

    # assemble full file: fixed header -> table_bytes -> data_blocks
    with open(out_path, 'wb') as out:
        # fixed header
        out.write(SIGNATURE)                       # 8
        out.write(struct.pack('<H', VERSION))      # 2
        out.write(struct.pack('<B', alg_ctx))      # 1
        out.write(struct.pack('<B', alg_noctx))    # 1
        out.write(struct.pack('<B', alg_prot))     # 1
        out.write(struct.pack('<B', RESERVED))     # 1
        out.write(struct.pack('<Q', header_size))  # 8
        out.write(struct.pack('<I', len(entries))) # 4

        # table
        out.write(table_bytes)

        # данные
        for block in data_blocks:
            out.write(block)

    # статистика
    total_orig = sum(orig_sizes)
    total_stored = os.path.getsize(out_path)
    print(f"Архив '{out_path}' создан. entries={len(entries)}, total_original_bytes={total_orig}, archive_size={total_stored}")
    print(f"alg_noctx={alg_noctx} (0=none,2=zlib). alg_prot={alg_prot} (0=none,11=crc32)")


def list_archive(archive_path):
    with open(archive_path, 'rb') as f:
        sig = f.read(8)
        if sig[:6] != SIGNATURE_PREFIX:
            raise ValueError("Неверная сигнатура (не L3ARCH...)")
        if sig != SIGNATURE:
            # допускаем совместимость: если первые 6 совпадают, но полная сигнатура иная, всё равно показываем
            pass
        version = struct.unpack('<H', f.read(2))[0]
        alg_ctx = ord(f.read(1))
        alg_noctx = ord(f.read(1))
        alg_prot = ord(f.read(1))
        _ = f.read(1)  # reserved
        header_size = struct.unpack('<Q', f.read(8))[0]
        num_entries = struct.unpack('<I', f.read(4))[0]

        print(f"Archive: {archive_path}")
        print(f" Signature: {sig!r}")
        print(f" Version: {version}")
        print(f" alg_ctx={alg_ctx}, alg_noctx={alg_noctx}, alg_prot={alg_prot}")
        print(f" header_size={header_size}, num_entries={num_entries}")
        print(" Entries:")
        for i in range(num_entries):
            entry_type = ord(f.read(1))
            path_len = struct.unpack('<H', f.read(2))[0]
            relpath = f.read(path_len).decode('utf-8')
            orig_size = struct.unpack('<Q', f.read(8))[0]
            stored_size = struct.unpack('<Q', f.read(8))[0]
            service_len = struct.unpack('<I', f.read(4))[0]
            service = f.read(service_len) if service_len else b''
            t = 'DIR' if entry_type == ENTRY_DIR else 'FILE'
            print(f"  {i}: {t} '{relpath}', orig={orig_size}, stored={stored_size}, service_len={service_len}")


def extract_archive(archive_path, out_dir):
    with open(archive_path, 'rb') as f:
        sig = f.read(8)
        if sig[:6] != SIGNATURE_PREFIX:
            raise ValueError("Неверная сигнатура (первые 6 байт не совпадают с L3ARCH)")
        version = struct.unpack('<H', f.read(2))[0]
        alg_ctx = ord(f.read(1))
        alg_noctx = ord(f.read(1))
        alg_prot = ord(f.read(1))
        _ = f.read(1)
        header_size = struct.unpack('<Q', f.read(8))[0]
        num_entries = struct.unpack('<I', f.read(4))[0]

        entries_meta = []
        for i in range(num_entries):
            entry_type = ord(f.read(1))
            path_len = struct.unpack('<H', f.read(2))[0]
            relpath = f.read(path_len).decode('utf-8')
            orig_size = struct.unpack('<Q', f.read(8))[0]
            stored_size = struct.unpack('<Q', f.read(8))[0]
            service_len = struct.unpack('<I', f.read(4))[0]
            service = f.read(service_len) if service_len else b''
            entries_meta.append((entry_type, relpath, orig_size, stored_size, service))

        # now f pointer at beginning of data area
        out_dir_path = Path(out_dir)
        out_dir_path.mkdir(parents=True, exist_ok=True)

        for entry_type, relpath, orig_size, stored_size, service in entries_meta:
            target_path = out_dir_path / Path(relpath)
            if entry_type == ENTRY_DIR:
                target_path.mkdir(parents=True, exist_ok=True)
                continue

            # ensure parent dir exists
            target_path.parent.mkdir(parents=True, exist_ok=True)
            stored_bytes = f.read(stored_size) if stored_size else b''

            # if protection CRC32 exists, check it against service (service is 4 bytes little-endian)
            if alg_prot == ALG_PROT_CRC32 and service:
                # service contains CRC32(original) for this file
                expected_crc = struct.unpack('<I', service)[0]
            else:
                expected_crc = None

            # decode (decompress) if alg_noctx = zlib
            if alg_noctx == ALG_NOCTX_ZLIB:
                raw = zlib.decompress(stored_bytes)
            else:
                raw = stored_bytes

            if expected_crc is not None:
                actual_crc = crc32(raw) & 0xffffffff
                if actual_crc != expected_crc:
                    print(f"Предупреждение: CRC mismatch for '{relpath}' (expected {expected_crc:08x}, got {actual_crc:08x})", file=sys.stderr)

            # sanity: orig_size check
            if len(raw) != orig_size:
                print(f"Предупреждение: размер распакованных данных для '{relpath}' != заявленному ({len(raw)} != {orig_size})", file=sys.stderr)

            # записываем файл
            with open(target_path, 'wb') as outf:
                outf.write(raw)
            print(f"Восстановлен: {relpath} -> {target_path}")

    print("Распаковка завершена.")


def main():
    parser = argparse.ArgumentParser(description="L3.№2 archiver (signature starts with 'L3ARCH').")
    sub = parser.add_subparsers(dest='cmd')

    enc = sub.add_parser('encode', help='Create archive')
    enc.add_argument('inputs', nargs='+', help='Files or directories to include (paths saved as relative in archive)')
    enc.add_argument('-o', '--out', required=True, help='Output archive file')
    enc.add_argument('--compress', action='store_true', help='Compress file contents using zlib (ALG_NOCTX=2)')
    enc.add_argument('--crc', action='store_true', help='Store CRC32 of original data (ALG_PROT=11)')

    dec = sub.add_parser('decode', help='Extract archive')
    dec.add_argument('archive', help='Archive file to extract')
    dec.add_argument('-d', '--outdir', default='.', help='Output directory')

    lst = sub.add_parser('list', help='List archive contents')
    lst.add_argument('archive', help='Archive file')

    args = parser.parse_args()

    if args.cmd == 'encode':
        entries = collect_entries(args.inputs)
        if not entries:
            print("Нет файлов/директорий для упаковки.", file=sys.stderr)
            return
        build_archive(entries, args.out, compress=args.compress, crc=args.crc)

    elif args.cmd == 'decode':
        extract_archive(args.archive, args.outdir)

    elif args.cmd == 'list':
        list_archive(args.archive)

    else:
        parser.print_help()


if __name__ == '__main__':
    main()